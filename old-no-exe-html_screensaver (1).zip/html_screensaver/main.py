"""
main.py
--------
Application entry point. Assumes dependencies are already installed --
run via bootstrap.py for automatic first-time dependency installation,
or run this directly once PySide6 / pywin32 are present.
"""

import sys
import ctypes


def _ensure_dpi_awareness():
    """
    Set Per-Monitor-V2 DPI awareness *before* creating QApplication so
    Qt does not fall back to system-DPI scaling. This is what makes
    multi-monitor setups with different scaling factors (e.g. a 4K
    150% laptop panel plus a 1080p 100% external monitor) render each
    screensaver window crisply on its own display instead of blurring
    one of them.
    """
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
    except (AttributeError, OSError):
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except (AttributeError, OSError):
            pass


def main():
    _ensure_dpi_awareness()

    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import Qt

    # High-DPI pixmaps so icons/dialogs stay sharp on scaled displays.
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)  # keep running in the tray with no visible windows
    app.setApplicationName("HtmlScreensaver")

    from PySide6.QtWidgets import QSystemTrayIcon, QMessageBox
    if not QSystemTrayIcon.isSystemTrayAvailable():
        QMessageBox.critical(None, "HTML Screensaver",
                              "No system tray is available on this system.")
        sys.exit(1)

    from src.tray_app import TrayApp

    autostart_launch = "--autostart" in sys.argv
    tray_app = TrayApp(app, autostart_launch=autostart_launch)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
